# Alfred使用技巧

[via](https://evsseny.appspot.com/?p=21001)

 general：general、keyboard、tweaking－－主要是一些普通设置，如开机启动、启动快捷键设置、国家位置、键盘键位设置和一些微调等，默认设置就可以了；

features：这是最重要的设置，综合一下有以下12项内容

1. 普通设置，包括应用程序、文件的搜索设置；
2. 搜索设置，包括已经提供的一些web搜索和自定义搜索；
3. 计算器，普通计算和函数计算
4. 字典
5. email－－可以开启网络邮箱，如gmail
6. address book
7. itunes,收费功能可调控itunes；
8. clipboard－－可以打开剪贴板历史和设置常用小段句子；
9. 系统命令－－屏幕保护、打开／清空垃圾站、强制退出、锁屏、重启、关机、推出光盘和隐藏、退出、强制退出打开的应用程序等；
10. 文件导航－－输入/或者alt＋＋/, ~home；
11. 全局热键定义；
12. 调用终端运行命令。

## 一些常用的命令：

- / 或previous                           文件导航；
- ~                                             home;
- find 文件名                            查找文件
- open 文件名                           打开文件
- in 关键字                                打开包含关键字的文件
- email 联系人                          发邮件
- find 文件名 ->选email to       发email附件
- clipboard                                 打开剪贴板历史
- recent documents                    最近使用的文档
- 》命令行                               调用终端
- =sin(23)                                  函数计算
- define  单词                            定义词
- spell    单词                            拼写检查
- itunes                                      itunes
- screensaver                             屏幕保护
- trash                                        打开垃圾站
- emptytrash                              清空垃圾站
- sleep                                        睡眠
- shutdown                                关机
- restart                                      重启
- logout                                      注销
- lock                                         锁屏
- hide 应用程序                        隐藏应用程序
- quit  应用程序                       退出应用程序
- forcequit 应用程序                强制退出应用程序
- eject                                        推出光盘