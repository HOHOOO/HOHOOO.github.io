---
layout: post
title: quick note
categories: []
tags: []
published: True

---

1. create a note directory
2. config sublime
3. connect gist
