Hi everybody, My name is Jimmy come from Nimble team, as you can see, the guy who is very nervous right now.

I am super existing to talk about progressive web app today, to build Native-like Mobile Web App, yep, this is my topic.

Firstly, it's show time, I already record a video which can give an introduction about our OSP web application. Let me open it, please wait a monent.

Okay, Let me recap: when user open our website by url, brower will popup an banner to reminder user can add to home screen; then user can click the icon as normal as Native app, we also have welcome page, and hidden brower address bar and menu bar, and it also can be an individual application process, rather than in browers.




