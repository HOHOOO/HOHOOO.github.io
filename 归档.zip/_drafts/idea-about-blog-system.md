---
layout: post
title: idea about blog system
categories: []
tags: []
published: True

---

- 加入产品讨论的gitter
- 兼容jekyll格式
- 文章放在Dropbox，`published: True`
- 各平台客户端
- 加入搜索功能
- 主题配色，彩虹系
- 集成到全页面里边的类kifi聊天框

终极目标就是，自动化爬虫，将任意博客内容转化为个人客户端（全平台）。
- Kimono转成JSON API，统一字段
- 平台化：用户得到固定API接口之后，就可以存储用户名密码，从而定制化自己的博客客户端
