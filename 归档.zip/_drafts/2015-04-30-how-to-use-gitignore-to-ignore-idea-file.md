---
layout: post
title: "how to use gitignore to ignore idea file"
description: ""
category: "编程"
tags: "[]"
---

- add more git command.

- gitignore