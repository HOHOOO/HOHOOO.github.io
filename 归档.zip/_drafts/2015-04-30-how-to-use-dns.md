---
layout: post
title: "How to use DNS"
description: ""
category: "技术"
tags: "GFW 域名"
---

内容：

- 如何申请域名.tk/not free

- 如何设置国内DNS

- 如何设置blog/photo子域名

- A CNAME

- GitHub加速