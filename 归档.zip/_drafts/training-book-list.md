
- 程序开发心理学(银年纪念版)
- JavaScript语言精髓与编程实践(第2版)
- 编写可维护的JavaScript
- 单页Web应用:JavaScript从前端到后端
- 传世经典书丛:UNIX编程艺术
- REST实战:中文版超媒体和系统架构
- 解码宇宙:新信息科学看天地万物