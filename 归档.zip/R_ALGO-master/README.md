R_ALGO
======
