---
layout: photo
title: 吕立青拍的壁纸系列（一）
categories: [摄影]
tags: [摄影, 爱情]
published: True

---

![//o7mw3gkkh.qnssl.com//S50615-150245.jpg](//o7mw3gkkh.qnssl.com//S50615-150245.jpg)
![//o7mw3gkkh.qnssl.com//S50616-152521.jpg](//o7mw3gkkh.qnssl.com//S50616-152521.jpg)
![//o7mw3gkkh.qnssl.com//S50616-160623.jpg](//o7mw3gkkh.qnssl.com//S50616-160623.jpg)
![//o7mw3gkkh.qnssl.com//S50616-160636.jpg](//o7mw3gkkh.qnssl.com//S50616-160636.jpg)
![//o7mw3gkkh.qnssl.com//S50616-160846.jpg](//o7mw3gkkh.qnssl.com//S50616-160846.jpg)
![//o7mw3gkkh.qnssl.com//S50616-160912.jpg](//o7mw3gkkh.qnssl.com//S50616-160912.jpg)

