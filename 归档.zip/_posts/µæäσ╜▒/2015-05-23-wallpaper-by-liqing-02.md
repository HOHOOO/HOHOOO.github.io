---
layout: photo
title: 吕立青拍的壁纸系列（二）
categories: [摄影]
tags: [摄影, 爱情]
published: True

---

![//o7mw3gkkh.qnssl.com//S50616-162617.jpg](//o7mw3gkkh.qnssl.com//S50616-162617.jpg)
![//o7mw3gkkh.qnssl.com//S50616-162654.jpg](//o7mw3gkkh.qnssl.com//S50616-162654.jpg)
![//o7mw3gkkh.qnssl.com//S50616-162720.jpg](//o7mw3gkkh.qnssl.com//S50616-162720.jpg)
![//o7mw3gkkh.qnssl.com//S50616-162738.jpg](//o7mw3gkkh.qnssl.com//S50616-162738.jpg)
![//o7mw3gkkh.qnssl.com//S50616-162805.jpg](//o7mw3gkkh.qnssl.com//S50616-162805.jpg)
![//o7mw3gkkh.qnssl.com//S50616-163002.jpg](//o7mw3gkkh.qnssl.com//S50616-163002.jpg)