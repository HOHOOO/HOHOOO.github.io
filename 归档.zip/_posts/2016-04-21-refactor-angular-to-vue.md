---
layout: post
title: 重构 AngularJS 到 VueJS
categories: [前端]
tags: [Vue, Angular, Refactoring]
published: False

---


> 来自于《Refactoring to Patterns》豆瓣书评，「模式的应用是一个渐进演变的过程」：大多数情况下，模式的应用是一个渐进演变的过程，坏味道也不是一开始就出现的，而在一开始就想到用这个模式，那个模式的，很可能导致设计过度。貌似重构与模式有一种天然的关系：重构是手段，模式是目的，同时模式也为重构指明了方向和原则。

《浮现式设计》  +  [重构到设计模式 - Growth-ebook](https://github.com/phodal/growth-ebook/blob/master/chapters%2F3.3.0-refactor-to-pattern.md)
