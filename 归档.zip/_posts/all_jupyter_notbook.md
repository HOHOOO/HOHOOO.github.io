---
layout: post
title: 关于交互这件小事 - 技术篇
categories: [前端]
tags: []
published: False

---

findById

onClick

data flow

database

Internet

界面编程而已，常见的，都可以在 Web 端学会，而且在 JavaScript 的渗透之下，越发激烈。