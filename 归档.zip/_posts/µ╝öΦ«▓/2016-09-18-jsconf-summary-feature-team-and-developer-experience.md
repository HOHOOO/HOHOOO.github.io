---
layout: iframe
title: 'JSConf 2016: What’s better Developer Experience & How to build FullStack Application by feature?'
categories: [演讲]
tags: [JavaScript, Conf, DX, FullStack]
speaker: Jimmy Lv
published: True
---

[slide]

# JSConf 2016

## What’s better Developer Experience & How to build FullStack Application by feature?

<small>via <strong>Jimmy Lv</strong></small>

[slide]

<iframe id="preview" style="height: 600px;" frameborder="0" width="100%" height="100%"
        src="https://jimmylv.github.io/jekyll-blog/slides/2016-09-18-jsconf-summary-feature-team-and-developer-experience.pdf">
</iframe>