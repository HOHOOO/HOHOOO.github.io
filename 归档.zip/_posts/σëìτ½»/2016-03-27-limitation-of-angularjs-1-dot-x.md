---
layout: post
title: AngularJS 1.x 版本的限制
categories: [前端]
tags: [AngularJS]
published: False

---

http://larseidnes.com/2014/11/05/angularjs-the-bad-parts/

https://github.com/xufei/blog/issues/9

https://angular.io/docs/ts/latest/guide/upgrade.html

https://github.com/AngularClass/NG6-todomvc-starter#learning-angularjs

https://angularclass.com/angular-2-components-angularjs-developers/

https://angularclass.com/angular-2-for-angularjs-developers/